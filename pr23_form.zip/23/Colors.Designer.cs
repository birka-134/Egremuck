﻿namespace _23
{
    partial class Colors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.color_show = new System.Windows.Forms.PictureBox();
            this.ok = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.ot_colors = new System.Windows.Forms.Button();
            this.red = new System.Windows.Forms.Label();
            this.green = new System.Windows.Forms.Label();
            this.blue = new System.Windows.Forms.Label();
            this.red_scroll = new System.Windows.Forms.HScrollBar();
            this.greenScroll = new System.Windows.Forms.HScrollBar();
            this.blueScroll = new System.Windows.Forms.HScrollBar();
            this.redNumeric = new System.Windows.Forms.NumericUpDown();
            this.greenNumeric = new System.Windows.Forms.NumericUpDown();
            this.blueNumeric = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.color_show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.redNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueNumeric)).BeginInit();
            this.SuspendLayout();
            // 
            // color_show
            // 
            this.color_show.Location = new System.Drawing.Point(320, 16);
            this.color_show.Name = "color_show";
            this.color_show.Size = new System.Drawing.Size(112, 101);
            this.color_show.TabIndex = 0;
            this.color_show.TabStop = false;
            // 
            // ok
            // 
            this.ok.Location = new System.Drawing.Point(10, 146);
            this.ok.Name = "ok";
            this.ok.Size = new System.Drawing.Size(106, 41);
            this.ok.TabIndex = 1;
            this.ok.Text = "Ок";
            this.ok.UseVisualStyleBackColor = true;
            this.ok.Click += new System.EventHandler(this.ok_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(132, 146);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(101, 41);
            this.cancel.TabIndex = 2;
            this.cancel.Text = "Отмена";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // ot_colors
            // 
            this.ot_colors.Location = new System.Drawing.Point(279, 146);
            this.ot_colors.Name = "ot_colors";
            this.ot_colors.Size = new System.Drawing.Size(160, 41);
            this.ot_colors.TabIndex = 3;
            this.ot_colors.Text = "Другие цвета";
            this.ot_colors.UseVisualStyleBackColor = true;
            this.ot_colors.Click += new System.EventHandler(this.ot_colors_Click);
            // 
            // red
            // 
            this.red.AutoSize = true;
            this.red.Location = new System.Drawing.Point(9, 12);
            this.red.Name = "red";
            this.red.Size = new System.Drawing.Size(52, 13);
            this.red.TabIndex = 4;
            this.red.Text = "Красный";
            // 
            // green
            // 
            this.green.AutoSize = true;
            this.green.Location = new System.Drawing.Point(9, 53);
            this.green.Name = "green";
            this.green.Size = new System.Drawing.Size(52, 13);
            this.green.TabIndex = 5;
            this.green.Text = "Зеленый";
            // 
            // blue
            // 
            this.blue.AutoSize = true;
            this.blue.Location = new System.Drawing.Point(12, 100);
            this.blue.Name = "blue";
            this.blue.Size = new System.Drawing.Size(38, 13);
            this.blue.TabIndex = 6;
            this.blue.Text = "Синий";
            // 
            // red_scroll
            // 
            this.red_scroll.LargeChange = 1;
            this.red_scroll.Location = new System.Drawing.Point(64, 9);
            this.red_scroll.Maximum = 255;
            this.red_scroll.Name = "red_scroll";
            this.red_scroll.Size = new System.Drawing.Size(182, 24);
            this.red_scroll.TabIndex = 7;
            this.red_scroll.ValueChanged += new System.EventHandler(this.red_scroll_ValueChanged);
            // 
            // greenScroll
            // 
            this.greenScroll.LargeChange = 1;
            this.greenScroll.Location = new System.Drawing.Point(64, 53);
            this.greenScroll.Maximum = 255;
            this.greenScroll.Name = "greenScroll";
            this.greenScroll.Size = new System.Drawing.Size(182, 24);
            this.greenScroll.TabIndex = 8;
            this.greenScroll.ValueChanged += new System.EventHandler(this.greenScroll_ValueChanged);
            // 
            // blueScroll
            // 
            this.blueScroll.LargeChange = 1;
            this.blueScroll.Location = new System.Drawing.Point(64, 100);
            this.blueScroll.Maximum = 255;
            this.blueScroll.Name = "blueScroll";
            this.blueScroll.Size = new System.Drawing.Size(182, 24);
            this.blueScroll.TabIndex = 9;
            this.blueScroll.ValueChanged += new System.EventHandler(this.blueScroll_ValueChanged);
            // 
            // redNumeric
            // 
            this.redNumeric.Location = new System.Drawing.Point(249, 13);
            this.redNumeric.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.redNumeric.Name = "redNumeric";
            this.redNumeric.Size = new System.Drawing.Size(36, 20);
            this.redNumeric.TabIndex = 10;
            this.redNumeric.ValueChanged += new System.EventHandler(this.redNumeric_ValueChanged);
            // 
            // greenNumeric
            // 
            this.greenNumeric.Location = new System.Drawing.Point(249, 57);
            this.greenNumeric.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.greenNumeric.Name = "greenNumeric";
            this.greenNumeric.Size = new System.Drawing.Size(36, 20);
            this.greenNumeric.TabIndex = 11;
            this.greenNumeric.ValueChanged += new System.EventHandler(this.greenNumeric_ValueChanged);
            // 
            // blueNumeric
            // 
            this.blueNumeric.Location = new System.Drawing.Point(249, 98);
            this.blueNumeric.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.blueNumeric.Name = "blueNumeric";
            this.blueNumeric.Size = new System.Drawing.Size(36, 20);
            this.blueNumeric.TabIndex = 12;
            this.blueNumeric.ValueChanged += new System.EventHandler(this.blueNumeric_ValueChanged);
            // 
            // Colors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 199);
            this.Controls.Add(this.blueNumeric);
            this.Controls.Add(this.greenNumeric);
            this.Controls.Add(this.redNumeric);
            this.Controls.Add(this.blueScroll);
            this.Controls.Add(this.greenScroll);
            this.Controls.Add(this.red_scroll);
            this.Controls.Add(this.blue);
            this.Controls.Add(this.green);
            this.Controls.Add(this.red);
            this.Controls.Add(this.ot_colors);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.ok);
            this.Controls.Add(this.color_show);
            this.Name = "Colors";
            this.Text = "Color";
            ((System.ComponentModel.ISupportInitialize)(this.color_show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.redNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueNumeric)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox color_show;
        private System.Windows.Forms.Button ok;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Button ot_colors;
        private System.Windows.Forms.Label red;
        private System.Windows.Forms.Label green;
        private System.Windows.Forms.Label blue;
        private System.Windows.Forms.HScrollBar red_scroll;
        private System.Windows.Forms.HScrollBar greenScroll;
        private System.Windows.Forms.HScrollBar blueScroll;
        private System.Windows.Forms.NumericUpDown redNumeric;
        private System.Windows.Forms.NumericUpDown greenNumeric;
        private System.Windows.Forms.NumericUpDown blueNumeric;
    }
}