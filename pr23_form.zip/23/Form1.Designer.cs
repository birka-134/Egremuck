﻿
namespace _23
{
	partial class PainLite
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PainLite));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.file = new System.Windows.Forms.ToolStripMenuItem();
            this.newFile = new System.Windows.Forms.ToolStripMenuItem();
            this.open = new System.Windows.Forms.ToolStripMenuItem();
            this.save = new System.Windows.Forms.ToolStripMenuItem();
            this.exit = new System.Windows.Forms.ToolStripMenuItem();
            this.edit = new System.Windows.Forms.ToolStripMenuItem();
            this.undo = new System.Windows.Forms.ToolStripMenuItem();
            this.reno = new System.Windows.Forms.ToolStripMenuItem();
            this.pen = new System.Windows.Forms.ToolStripMenuItem();
            this.style = new System.Windows.Forms.ToolStripMenuItem();
            this.solid = new System.Windows.Forms.ToolStripMenuItem();
            this.dot = new System.Windows.Forms.ToolStripMenuItem();
            this.dashDotDot = new System.Windows.Forms.ToolStripMenuItem();
            this.color = new System.Windows.Forms.ToolStripMenuItem();
            this.help = new System.Windows.Forms.ToolStripMenuItem();
            this.about = new System.Windows.Forms.ToolStripMenuItem();
            this.picDrawingSurface = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tt = new System.Windows.Forms.Label();
            this.width = new System.Windows.Forms.TrackBar();
            this.instruments = new System.Windows.Forms.ToolStrip();
            this.fastNew = new System.Windows.Forms.ToolStripButton();
            this.fastSave = new System.Windows.Forms.ToolStripButton();
            this.fastImport = new System.Windows.Forms.ToolStripButton();
            this.fastColor = new System.Windows.Forms.ToolStripButton();
            this.fastExit = new System.Windows.Forms.ToolStripButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDrawingSurface)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.width)).BeginInit();
            this.instruments.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.file,
            this.edit,
            this.help});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(999, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // file
            // 
            this.file.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFile,
            this.open,
            this.save,
            this.exit});
            this.file.Name = "file";
            this.file.Size = new System.Drawing.Size(37, 20);
            this.file.Text = "File";
            // 
            // newFile
            // 
            this.newFile.Image = ((System.Drawing.Image)(resources.GetObject("newFile.Image")));
            this.newFile.Name = "newFile";
            this.newFile.ShortcutKeyDisplayString = "CTRL+N";
            this.newFile.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newFile.Size = new System.Drawing.Size(185, 22);
            this.newFile.Text = "New            ";
            this.newFile.Click += new System.EventHandler(this.new_Click);
            // 
            // open
            // 
            this.open.Image = ((System.Drawing.Image)(resources.GetObject("open.Image")));
            this.open.Name = "open";
            this.open.ShortcutKeyDisplayString = "F3";
            this.open.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.open.Size = new System.Drawing.Size(185, 22);
            this.open.Text = "Open";
            this.open.Click += new System.EventHandler(this.open_Click);
            // 
            // save
            // 
            this.save.Image = ((System.Drawing.Image)(resources.GetObject("save.Image")));
            this.save.Name = "save";
            this.save.ShortcutKeyDisplayString = "F2";
            this.save.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.save.Size = new System.Drawing.Size(185, 22);
            this.save.Text = "Save ";
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // exit
            // 
            this.exit.Image = ((System.Drawing.Image)(resources.GetObject("exit.Image")));
            this.exit.Name = "exit";
            this.exit.ShortcutKeyDisplayString = "Alt+X";
            this.exit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.X)));
            this.exit.Size = new System.Drawing.Size(185, 22);
            this.exit.Text = "Exit             ";
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // edit
            // 
            this.edit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undo,
            this.reno,
            this.pen});
            this.edit.Name = "edit";
            this.edit.Size = new System.Drawing.Size(39, 20);
            this.edit.Text = "Edit";
            // 
            // undo
            // 
            this.undo.Image = ((System.Drawing.Image)(resources.GetObject("undo.Image")));
            this.undo.Name = "undo";
            this.undo.ShortcutKeyDisplayString = "CTRL+Z";
            this.undo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.undo.Size = new System.Drawing.Size(197, 22);
            this.undo.Text = "Undo         ";
            this.undo.Click += new System.EventHandler(this.undo_Click);
            // 
            // reno
            // 
            this.reno.Image = ((System.Drawing.Image)(resources.GetObject("reno.Image")));
            this.reno.Name = "reno";
            this.reno.ShortcutKeyDisplayString = "CTRL+Shift+Z";
            this.reno.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.Z)));
            this.reno.Size = new System.Drawing.Size(197, 22);
            this.reno.Text = "Reno     ";
            this.reno.Click += new System.EventHandler(this.reno_Click);
            // 
            // pen
            // 
            this.pen.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.style,
            this.color});
            this.pen.Image = ((System.Drawing.Image)(resources.GetObject("pen.Image")));
            this.pen.Name = "pen";
            this.pen.Size = new System.Drawing.Size(197, 22);
            this.pen.Text = "Pen";
            // 
            // style
            // 
            this.style.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.solid,
            this.dot,
            this.dashDotDot});
            this.style.Name = "style";
            this.style.Size = new System.Drawing.Size(103, 22);
            this.style.Text = "Style";
            // 
            // solid
            // 
            this.solid.CheckOnClick = true;
            this.solid.Name = "solid";
            this.solid.Size = new System.Drawing.Size(138, 22);
            this.solid.Text = "Solid";
            this.solid.Click += new System.EventHandler(this.solid_Click);
            // 
            // dot
            // 
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(138, 22);
            this.dot.Text = "Dot";
            this.dot.Click += new System.EventHandler(this.dot_Click);
            // 
            // dashDotDot
            // 
            this.dashDotDot.Name = "dashDotDot";
            this.dashDotDot.Size = new System.Drawing.Size(138, 22);
            this.dashDotDot.Text = "DashDotDot";
            this.dashDotDot.Click += new System.EventHandler(this.dashDotDot_Click);
            // 
            // color
            // 
            this.color.Image = ((System.Drawing.Image)(resources.GetObject("color.Image")));
            this.color.Name = "color";
            this.color.Size = new System.Drawing.Size(103, 22);
            this.color.Text = "Color";
            this.color.Click += new System.EventHandler(this.color_Click);
            // 
            // help
            // 
            this.help.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.about});
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(44, 20);
            this.help.Text = "Help";
            // 
            // about
            // 
            this.about.Image = ((System.Drawing.Image)(resources.GetObject("about.Image")));
            this.about.Name = "about";
            this.about.ShortcutKeyDisplayString = "F1";
            this.about.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.about.Size = new System.Drawing.Size(144, 22);
            this.about.Text = "About      ";
            this.about.Click += new System.EventHandler(this.about_Click);
            // 
            // picDrawingSurface
            // 
            this.picDrawingSurface.BackColor = System.Drawing.Color.White;
            this.picDrawingSurface.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picDrawingSurface.Location = new System.Drawing.Point(71, 28);
            this.picDrawingSurface.Name = "picDrawingSurface";
            this.picDrawingSurface.Size = new System.Drawing.Size(900, 520);
            this.picDrawingSurface.TabIndex = 1;
            this.picDrawingSurface.TabStop = false;
            this.picDrawingSurface.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDrawingSurface_MouseDown);
            this.picDrawingSurface.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picDrawingSurface_MouseMove);
            this.picDrawingSurface.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picDrawingSurface_MouseUp);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tt);
            this.panel1.Controls.Add(this.width);
            this.panel1.Location = new System.Drawing.Point(63, 574);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(899, 40);
            this.panel1.TabIndex = 2;
            // 
            // tt
            // 
            this.tt.AutoSize = true;
            this.tt.Location = new System.Drawing.Point(143, -2);
            this.tt.Name = "tt";
            this.tt.Size = new System.Drawing.Size(35, 13);
            this.tt.TabIndex = 1;
            this.tt.Text = "label1";
            // 
            // width
            // 
            this.width.AutoSize = false;
            this.width.Location = new System.Drawing.Point(628, 0);
            this.width.Name = "width";
            this.width.Size = new System.Drawing.Size(271, 40);
            this.width.TabIndex = 0;
            this.width.Value = 4;
            this.width.Scroll += new System.EventHandler(this.width_Scroll);
            // 
            // instruments
            // 
            this.instruments.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.instruments.AutoSize = false;
            this.instruments.Dock = System.Windows.Forms.DockStyle.None;
            this.instruments.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fastNew,
            this.fastSave,
            this.fastImport,
            this.fastColor,
            this.fastExit});
            this.instruments.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.instruments.Location = new System.Drawing.Point(0, 132);
            this.instruments.Name = "instruments";
            this.instruments.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.instruments.Size = new System.Drawing.Size(60, 345);
            this.instruments.Stretch = true;
            this.instruments.TabIndex = 3;
            this.instruments.Text = "toolStrip1";
            // 
            // fastNew
            // 
            this.fastNew.AutoSize = false;
            this.fastNew.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fastNew.BackgroundImage")));
            this.fastNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fastNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fastNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.fastNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fastNew.Name = "fastNew";
            this.fastNew.Size = new System.Drawing.Size(60, 60);
            this.fastNew.Click += new System.EventHandler(this.fastNew_Click);
            // 
            // fastSave
            // 
            this.fastSave.AutoSize = false;
            this.fastSave.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fastSave.BackgroundImage")));
            this.fastSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fastSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fastSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fastSave.Name = "fastSave";
            this.fastSave.Size = new System.Drawing.Size(60, 60);
            this.fastSave.Click += new System.EventHandler(this.fastSave_Click_1);
            // 
            // fastImport
            // 
            this.fastImport.AutoSize = false;
            this.fastImport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fastImport.BackgroundImage")));
            this.fastImport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fastImport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fastImport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fastImport.Name = "fastImport";
            this.fastImport.Size = new System.Drawing.Size(60, 60);
            this.fastImport.Click += new System.EventHandler(this.fastImport_Click);
            // 
            // fastColor
            // 
            this.fastColor.AutoSize = false;
            this.fastColor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fastColor.BackgroundImage")));
            this.fastColor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fastColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fastColor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fastColor.Name = "fastColor";
            this.fastColor.Size = new System.Drawing.Size(60, 60);
            this.fastColor.Click += new System.EventHandler(this.fastColor_Click);
            // 
            // fastExit
            // 
            this.fastExit.AutoSize = false;
            this.fastExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fastExit.BackgroundImage")));
            this.fastExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fastExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.fastExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fastExit.Name = "fastExit";
            this.fastExit.Size = new System.Drawing.Size(60, 60);
            this.fastExit.Click += new System.EventHandler(this.fastExit_Click);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(56, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(943, 544);
            this.panel2.TabIndex = 4;
            // 
            // PainLite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 609);
            this.Controls.Add(this.instruments);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.picDrawingSurface);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel2);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "PainLite";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDrawingSurface)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.width)).EndInit();
            this.instruments.ResumeLayout(false);
            this.instruments.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem file;
		private System.Windows.Forms.ToolStripMenuItem newFile;
		private System.Windows.Forms.ToolStripMenuItem open;
		private System.Windows.Forms.ToolStripMenuItem save;
		private System.Windows.Forms.ToolStripMenuItem exit;
		private System.Windows.Forms.ToolStripMenuItem edit;
		private System.Windows.Forms.ToolStripMenuItem undo;
		private System.Windows.Forms.ToolStripMenuItem reno;
		private System.Windows.Forms.ToolStripMenuItem pen;
		private System.Windows.Forms.ToolStripMenuItem style;
		private System.Windows.Forms.ToolStripMenuItem solid;
		private System.Windows.Forms.ToolStripMenuItem dot;
		private System.Windows.Forms.ToolStripMenuItem dashDotDot;
		private System.Windows.Forms.ToolStripMenuItem color;
		private System.Windows.Forms.ToolStripMenuItem help;
		private System.Windows.Forms.ToolStripMenuItem about;
		private System.Windows.Forms.PictureBox picDrawingSurface;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TrackBar width;
		private System.Windows.Forms.ToolStrip instruments;
		private System.Windows.Forms.ToolStripButton fastNew;
		private System.Windows.Forms.ToolStripButton fastSave;
		private System.Windows.Forms.ToolStripButton fastImport;
		private System.Windows.Forms.ToolStripButton fastColor;
		private System.Windows.Forms.ToolStripButton fastExit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label tt;
    }
}

