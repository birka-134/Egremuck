﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _23
{
    public partial class PainLite : Form
    {
        bool drawing;
        int historyCounter; //Счетчик истории 
        GraphicsPath currentPath;
        Point oldLocation;
        public Pen currentPen;
        public Color historyColor;//Сохранение текущего цвета перед использованием ластика 
        List<Image> History;
        public PainLite()
        {
            InitializeComponent();
            drawing = false; //Переменная, ответственная за рисование 
            currentPen = new Pen(Color.Black);//Инициализация пера с черным цветом 
            currentPen.Width = width.Value; //Инициализация толщины пера 
            History = new List<Image>();

        }

        private void save_Click(object sender, EventArgs e)
        {
            SaveFileDialog SaveDlg = new SaveFileDialog();
            SaveDlg.Filter = "JPEG Image|*.jpg|Bitmap Image|*.bmp|GIF Image|*.gif|PNG Image|*.png";
            SaveDlg.Title = "Save an Image File";
            SaveDlg.FilterIndex = 4; //По умолчанию будет выбрано последнее расширение *.png
            SaveDlg.ShowDialog();
            if (SaveDlg.FileName != "") //Если введено не пустое имя 
            {
                System.IO.FileStream fs = (System.IO.FileStream)SaveDlg.OpenFile();
                switch (SaveDlg.FilterIndex)
                {
                    case 1:
                        this.picDrawingSurface.Image.Save(fs, ImageFormat.Jpeg);
                        break;
                    case 2:
                        this.picDrawingSurface.Image.Save(fs, ImageFormat.Bmp);
                        break;
                    case 3:
                        this.picDrawingSurface.Image.Save(fs, ImageFormat.Gif);
                        break;
                    case 4:
                        this.picDrawingSurface.Image.Save(fs, ImageFormat.Png);
                        break;
                }
                fs.Close();
            }
            Graphics g = Graphics.FromImage(picDrawingSurface.Image);
            g.Clear(Color.White);
            g.DrawImage(picDrawingSurface.Image, 0, 0, 750, 500);

        }

     
        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void fastExit_Click(object sender, EventArgs e)
        {
            exit_Click(sender, e);
        }

        private void about_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Paint (pr23)");
        }


        private void new_Click(object sender, EventArgs e)
        {
            History.Clear();
            historyCounter = 0;
            Bitmap pic = new Bitmap(900, 520);
            picDrawingSurface.Image = pic;
            History.Add(new Bitmap(picDrawingSurface.Image));
            if (picDrawingSurface.Image != null)
            {
                var result = MessageBox.Show("Сохранить текущее изображение перед созданием нового рисунка?", "Предупреждение", MessageBoxButtons.YesNoCancel);

                switch (result)
                {
                    case DialogResult.No:
                        break;
                    case DialogResult.Yes:
                        save_Click(sender, e);
                        break;
                    case DialogResult.Cancel:
                        return;
                }

            }

        }

        private void fastNew_Click(object sender, EventArgs e)
        {
            new_Click(sender, e);
        }

        private void picDrawingSurface_MouseDown(object sender, MouseEventArgs e)
        {
            if (picDrawingSurface.Image == null)
            {
                MessageBox.Show("Сначала создайте новый файл!");
                return;
            }
            if (e.Button == MouseButtons.Left)
            {
                drawing = true;
                historyColor = currentPen.Color;
                oldLocation = e.Location;
                currentPath = new GraphicsPath();
            }
            if (e.Button == MouseButtons.Right)
            {
                drawing = true;
                historyColor = currentPen.Color;
                currentPen.Color = Color.White;
                oldLocation = e.Location;
                currentPath = new GraphicsPath();
            }

        }
        private void picDrawingSurface_MouseUp(object sender, MouseEventArgs e)
        {
            //очистка ненужной истории
            History.RemoveRange(historyCounter + 1, History.Count - historyCounter - 1);
            History.Add(new Bitmap(picDrawingSurface.Image));
            if (historyCounter + 1 < 10)
                historyCounter++;
            if (History.Count - 1 == 10)
                History.RemoveAt(0);
            currentPen.Color = historyColor;
            drawing = false;
            try
            {
                currentPath.Dispose();
            }
            catch { };

        }
        private void picDrawingSurface_MouseMove(object sender, MouseEventArgs e)
        {
            tt.Text = e.X.ToString() + ", " + e.Y.ToString();
            if (drawing)
            {
                Graphics g = Graphics.FromImage(picDrawingSurface.Image);
                currentPath.AddLine(oldLocation, e.Location);
                g.DrawPath(currentPen, currentPath);
                oldLocation = e.Location;
                g.Dispose();
                picDrawingSurface.Invalidate();
            }

        }
        private void open_Click(object sender, EventArgs e)
        {
            OpenFileDialog OP = new OpenFileDialog();
            OP.Filter = "JPEG Image|*.jpg|Bitmap Image|*.bmp|GIF Image|*.gif|PNG Image|*.png";
            OP.Title = "Open an Image File";
            OP.FilterIndex = 1; //По умолчанию будет выбрано первое расширение *.jpg

            if (OP.ShowDialog() != DialogResult.Cancel)
            {
                picDrawingSurface.Load(OP.FileName);
                picDrawingSurface.AutoSize = true;
            }
        }

        private void width_Scroll(object sender, EventArgs e)
        {
            currentPen.Width = width.Value;
        }

        private void undo_Click(object sender, EventArgs e)
        {
            if (History.Count != 0 && historyCounter != 0)
            {
                picDrawingSurface.Image = new Bitmap(History[--historyCounter]);
            }
            else MessageBox.Show("История пуста");

        }

        private void reno_Click(object sender, EventArgs e)
        {
            if (historyCounter < History.Count - 1)
            {
                picDrawingSurface.Image = new Bitmap(History[++historyCounter]);
            }
            else MessageBox.Show("История пуста");

        }

        private void solid_Click(object sender, EventArgs e)
        {
            currentPen.DashStyle = DashStyle.Solid;
            solid.Checked = true;
            dot.Checked = false;
            dashDotDot.Checked = false;

        }

        private void dot_Click(object sender, EventArgs e)
        {
            currentPen.DashStyle = DashStyle.Dot;
            solid.Checked = false;
            dot.Checked = true;
            dashDotDot.Checked = false;
        }

        private void dashDotDot_Click(object sender, EventArgs e)
        {
            currentPen.DashStyle = DashStyle.DashDotDot;
            solid.Checked = false;
            dot.Checked = false;
            dashDotDot.Checked = true;
        }

        private void fastColor_Click(object sender, EventArgs e)
        {
            Colors f = new Colors(this.currentPen.Color);
            f.Owner = this;
            f.ShowDialog();
        }

        private void color_Click(object sender, EventArgs e)
        {
            fastColor_Click(sender, e);
        }

        private void fastImport_Click(object sender, EventArgs e)
        {
            open_Click(sender, e);
        }

        private void fastSave_Click_1(object sender, EventArgs e)
        {
            save_Click(sender, e);
        }
    }
}



