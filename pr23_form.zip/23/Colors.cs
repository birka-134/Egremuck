﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _23
{
    public partial class Colors : Form
    {
        public Color colorResult;
        public Colors(Color color)
        {
            InitializeComponent();
            red_scroll.Tag = redNumeric;
            greenScroll.Tag = greenNumeric;
            blueScroll.Tag = blueNumeric;
            redNumeric.Tag = red_scroll;
            greenNumeric.Tag = greenScroll;
            blueNumeric.Tag = blueScroll;
            redNumeric.Value = color.R;
            greenNumeric.Value = color.G;
            blueNumeric.Value = color.B;

        }

        private void red_scroll_ValueChanged(object sender, EventArgs e)
        {
            HScrollBar scrollBar = (HScrollBar)sender;
            NumericUpDown numericUpDown = (NumericUpDown)scrollBar.Tag;
            numericUpDown.Value = scrollBar.Value;

        }

        private void redNumeric_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown numericUpDown = (NumericUpDown)sender;
            HScrollBar scrollBar = (HScrollBar)numericUpDown.Tag;
            scrollBar.Value = (int)numericUpDown.Value;
            UpdateColor();

        }

        private void greenScroll_ValueChanged(object sender, EventArgs e)
        {
            HScrollBar scrollBar = (HScrollBar)sender;
            NumericUpDown numericUpDown = (NumericUpDown)scrollBar.Tag;
            numericUpDown.Value = scrollBar.Value;
        }

        private void greenNumeric_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown numericUpDown = (NumericUpDown)sender;
            HScrollBar scrollBar = (HScrollBar)numericUpDown.Tag;
            scrollBar.Value = (int)numericUpDown.Value;
            UpdateColor();
        }

        private void blueScroll_ValueChanged(object sender, EventArgs e)
        {
            HScrollBar scrollBar = (HScrollBar)sender;
            NumericUpDown numericUpDown = (NumericUpDown)scrollBar.Tag;
            numericUpDown.Value = scrollBar.Value;
        }

        private void blueNumeric_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown numericUpDown = (NumericUpDown)sender;
            HScrollBar scrollBar = (HScrollBar)numericUpDown.Tag;
            scrollBar.Value = (int)numericUpDown.Value;
            UpdateColor();
        }
        private void UpdateColor()
        {
            colorResult = Color.FromArgb(red_scroll.Value, greenScroll.Value, blueScroll.Value);
            color_show.BackColor = colorResult;
        }

        private void ot_colors_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                red_scroll.Value = colorDialog.Color.R;
                greenScroll.Value = colorDialog.Color.G;
                blueScroll.Value = colorDialog.Color.B;
                colorResult = colorDialog.Color;
                UpdateColor();
            }

        }

        private void ok_Click(object sender, EventArgs e)
        {
            PainLite main = this.Owner as PainLite;
            main.currentPen.Color = colorResult;
            Close();
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
