﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_25
{
    public partial class info : Form
    {
        public info()
        {
            InitializeComponent();
        }
        public DateTime DateEnd;
        private void info_Load(object sender, EventArgs e)
        {
            DateEnd = new DateTime(2024, 2, 26, 8, 30, 0);
            timer.Start();
        }
        private void timer_Tick(object sender, EventArgs e)
        {
            timer_to_begin.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", DateEnd - DateTime.Now);
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

		private void pictureBox1_Click(object sender, EventArgs e)
		{
            intMap f = new intMap();
            this.Hide();
            f.ShowDialog();
            this.Show();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
