﻿namespace pr_25
{
    partial class begin
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.timer_to_begin = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.map_bt = new System.Windows.Forms.Button();
            this.speed = new System.Windows.Forms.Button();
            this.BMI = new System.Windows.Forms.Button();
            this.BMR = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(959, 58);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(69, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "MARATHON SKILLS 2016";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.timer_to_begin);
            this.panel2.Location = new System.Drawing.Point(0, 491);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(959, 42);
            this.panel2.TabIndex = 1;
            // 
            // timer_to_begin
            // 
            this.timer_to_begin.AutoSize = true;
            this.timer_to_begin.Location = new System.Drawing.Point(307, 15);
            this.timer_to_begin.Name = "timer_to_begin";
            this.timer_to_begin.Size = new System.Drawing.Size(269, 13);
            this.timer_to_begin.TabIndex = 0;
            this.timer_to_begin.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(202, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(513, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "ИНФОРМАЦИЯ О MARATHON SKILLS 2016";
            // 
            // map_bt
            // 
            this.map_bt.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.map_bt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.map_bt.Font = new System.Drawing.Font("Arial", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.map_bt.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.map_bt.Location = new System.Drawing.Point(199, 184);
            this.map_bt.Name = "map_bt";
            this.map_bt.Size = new System.Drawing.Size(220, 85);
            this.map_bt.TabIndex = 3;
            this.map_bt.Text = "Marathon Skills 2016";
            this.map_bt.UseVisualStyleBackColor = false;
            this.map_bt.Click += new System.EventHandler(this.map_bt_Click);
            // 
            // speed
            // 
            this.speed.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.speed.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.speed.Font = new System.Drawing.Font("Arial", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.speed.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.speed.Location = new System.Drawing.Point(483, 184);
            this.speed.Name = "speed";
            this.speed.Size = new System.Drawing.Size(224, 85);
            this.speed.TabIndex = 4;
            this.speed.Text = "Насколько долгий марафон";
            this.speed.UseVisualStyleBackColor = false;
            this.speed.Click += new System.EventHandler(this.speed_Click);
            // 
            // BMI
            // 
            this.BMI.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BMI.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BMI.Font = new System.Drawing.Font("Arial", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.BMI.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BMI.Location = new System.Drawing.Point(199, 294);
            this.BMI.Name = "BMI";
            this.BMI.Size = new System.Drawing.Size(220, 84);
            this.BMI.TabIndex = 5;
            this.BMI.Text = "BMI калькулятор";
            this.BMI.UseVisualStyleBackColor = false;
            this.BMI.Click += new System.EventHandler(this.BMI_Click);
            // 
            // BMR
            // 
            this.BMR.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BMR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BMR.Font = new System.Drawing.Font("Arial", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.BMR.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BMR.Location = new System.Drawing.Point(483, 294);
            this.BMR.Name = "BMR";
            this.BMR.Size = new System.Drawing.Size(224, 84);
            this.BMR.TabIndex = 6;
            this.BMR.Text = "BMR калькулятор";
            this.BMR.UseVisualStyleBackColor = false;
            this.BMR.Click += new System.EventHandler(this.BMR_Click);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // begin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(888, 532);
            this.Controls.Add(this.BMR);
            this.Controls.Add(this.BMI);
            this.Controls.Add(this.speed);
            this.Controls.Add(this.map_bt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "begin";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label timer_to_begin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button speed;
        private System.Windows.Forms.Button BMI;
        private System.Windows.Forms.Button BMR;
		public System.Windows.Forms.Button map_bt;
        private System.Windows.Forms.Timer timer;
    }
}

