﻿namespace pr_25
{
    partial class intMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(intMap));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.back = new System.Windows.Forms.Button();
            this.map = new System.Windows.Forms.PictureBox();
            this.ch1 = new System.Windows.Forms.Button();
            this.ch2 = new System.Windows.Forms.Button();
            this.ch3 = new System.Windows.Forms.Button();
            this.ch4 = new System.Windows.Forms.Button();
            this.ch5 = new System.Windows.Forms.Button();
            this.ch6 = new System.Windows.Forms.Button();
            this.ch7 = new System.Windows.Forms.Button();
            this.ch8 = new System.Windows.Forms.Button();
            this.start_m = new System.Windows.Forms.Button();
            this.infoCheck = new System.Windows.Forms.Panel();
            this.close = new System.Windows.Forms.PictureBox();
            this.medic = new System.Windows.Forms.PictureBox();
            this.info = new System.Windows.Forms.PictureBox();
            this.toulet = new System.Windows.Forms.PictureBox();
            this.energy = new System.Windows.Forms.PictureBox();
            this.drinks = new System.Windows.Forms.PictureBox();
            this.description = new System.Windows.Forms.Label();
            this.infCheck = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.map)).BeginInit();
            this.infoCheck.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.info)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toulet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.energy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.drinks)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(177, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(559, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Интерактивная карта MARATHON SKILLS 2016";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.back);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-35, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(959, 58);
            this.panel1.TabIndex = 1;
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(61, 20);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 1;
            this.back.Text = "Назад";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // map
            // 
            this.map.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("map.BackgroundImage")));
            this.map.Location = new System.Drawing.Point(12, 63);
            this.map.Name = "map";
            this.map.Size = new System.Drawing.Size(516, 455);
            this.map.TabIndex = 2;
            this.map.TabStop = false;
            // 
            // ch1
            // 
            this.ch1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ch1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ch1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ch1.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ch1.ForeColor = System.Drawing.Color.Black;
            this.ch1.Location = new System.Drawing.Point(293, 71);
            this.ch1.Name = "ch1";
            this.ch1.Size = new System.Drawing.Size(51, 49);
            this.ch1.TabIndex = 3;
            this.ch1.Text = "1";
            this.ch1.UseVisualStyleBackColor = false;
            this.ch1.Click += new System.EventHandler(this.ch1_Click);
            // 
            // ch2
            // 
            this.ch2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ch2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ch2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ch2.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ch2.ForeColor = System.Drawing.Color.Black;
            this.ch2.Location = new System.Drawing.Point(350, 195);
            this.ch2.Name = "ch2";
            this.ch2.Size = new System.Drawing.Size(51, 49);
            this.ch2.TabIndex = 4;
            this.ch2.Text = "2";
            this.ch2.UseVisualStyleBackColor = false;
            this.ch2.Click += new System.EventHandler(this.ch2_Click);
            // 
            // ch3
            // 
            this.ch3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ch3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ch3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ch3.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ch3.ForeColor = System.Drawing.Color.Black;
            this.ch3.Location = new System.Drawing.Point(337, 281);
            this.ch3.Name = "ch3";
            this.ch3.Size = new System.Drawing.Size(51, 49);
            this.ch3.TabIndex = 5;
            this.ch3.Text = "3";
            this.ch3.UseVisualStyleBackColor = false;
            this.ch3.Click += new System.EventHandler(this.ch3_Click);
            // 
            // ch4
            // 
            this.ch4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ch4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ch4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ch4.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ch4.ForeColor = System.Drawing.Color.Black;
            this.ch4.Location = new System.Drawing.Point(457, 377);
            this.ch4.Name = "ch4";
            this.ch4.Size = new System.Drawing.Size(51, 49);
            this.ch4.TabIndex = 6;
            this.ch4.Text = "4";
            this.ch4.UseVisualStyleBackColor = false;
            this.ch4.Click += new System.EventHandler(this.ch4_Click);
            // 
            // ch5
            // 
            this.ch5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ch5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ch5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ch5.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ch5.ForeColor = System.Drawing.Color.Black;
            this.ch5.Location = new System.Drawing.Point(268, 439);
            this.ch5.Name = "ch5";
            this.ch5.Size = new System.Drawing.Size(51, 49);
            this.ch5.TabIndex = 7;
            this.ch5.Text = "5";
            this.ch5.UseVisualStyleBackColor = false;
            this.ch5.Click += new System.EventHandler(this.ch5_Click);
            // 
            // ch6
            // 
            this.ch6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ch6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ch6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ch6.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ch6.ForeColor = System.Drawing.Color.Black;
            this.ch6.Location = new System.Drawing.Point(116, 394);
            this.ch6.Name = "ch6";
            this.ch6.Size = new System.Drawing.Size(51, 49);
            this.ch6.TabIndex = 8;
            this.ch6.Text = "6";
            this.ch6.UseVisualStyleBackColor = false;
            this.ch6.Click += new System.EventHandler(this.ch6_Click);
            // 
            // ch7
            // 
            this.ch7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ch7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ch7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ch7.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ch7.ForeColor = System.Drawing.Color.Black;
            this.ch7.Location = new System.Drawing.Point(72, 319);
            this.ch7.Name = "ch7";
            this.ch7.Size = new System.Drawing.Size(51, 49);
            this.ch7.TabIndex = 9;
            this.ch7.Text = "7";
            this.ch7.UseVisualStyleBackColor = false;
            this.ch7.Click += new System.EventHandler(this.ch7_Click);
            // 
            // ch8
            // 
            this.ch8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ch8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ch8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ch8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ch8.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ch8.ForeColor = System.Drawing.Color.Black;
            this.ch8.Location = new System.Drawing.Point(57, 191);
            this.ch8.Name = "ch8";
            this.ch8.Size = new System.Drawing.Size(51, 49);
            this.ch8.TabIndex = 10;
            this.ch8.Text = "8";
            this.ch8.UseVisualStyleBackColor = false;
            this.ch8.Click += new System.EventHandler(this.ch8_Click);
            // 
            // start_m
            // 
            this.start_m.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.start_m.BackColor = System.Drawing.SystemColors.Control;
            this.start_m.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.start_m.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.start_m.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.start_m.Location = new System.Drawing.Point(155, 71);
            this.start_m.Name = "start_m";
            this.start_m.Size = new System.Drawing.Size(56, 84);
            this.start_m.TabIndex = 11;
            this.start_m.Text = "start";
            this.start_m.UseVisualStyleBackColor = false;
            this.start_m.Click += new System.EventHandler(this.start_m_Click);
            // 
            // infoCheck
            // 
            this.infoCheck.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.infoCheck.Controls.Add(this.close);
            this.infoCheck.Controls.Add(this.medic);
            this.infoCheck.Controls.Add(this.info);
            this.infoCheck.Controls.Add(this.toulet);
            this.infoCheck.Controls.Add(this.energy);
            this.infoCheck.Controls.Add(this.drinks);
            this.infoCheck.Controls.Add(this.description);
            this.infoCheck.Controls.Add(this.infCheck);
            this.infoCheck.Location = new System.Drawing.Point(534, 63);
            this.infoCheck.Name = "infoCheck";
            this.infoCheck.Size = new System.Drawing.Size(352, 379);
            this.infoCheck.TabIndex = 12;
            // 
            // close
            // 
            this.close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("close.BackgroundImage")));
            this.close.Location = new System.Drawing.Point(322, 10);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(20, 20);
            this.close.TabIndex = 19;
            this.close.TabStop = false;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // medic
            // 
            this.medic.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("medic.BackgroundImage")));
            this.medic.Location = new System.Drawing.Point(19, 212);
            this.medic.Name = "medic";
            this.medic.Size = new System.Drawing.Size(25, 25);
            this.medic.TabIndex = 18;
            this.medic.TabStop = false;
            // 
            // info
            // 
            this.info.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("info.BackgroundImage")));
            this.info.Location = new System.Drawing.Point(19, 172);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(25, 25);
            this.info.TabIndex = 17;
            this.info.TabStop = false;
            // 
            // toulet
            // 
            this.toulet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toulet.BackgroundImage")));
            this.toulet.Location = new System.Drawing.Point(19, 132);
            this.toulet.Name = "toulet";
            this.toulet.Size = new System.Drawing.Size(25, 25);
            this.toulet.TabIndex = 16;
            this.toulet.TabStop = false;
            // 
            // energy
            // 
            this.energy.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("energy.BackgroundImage")));
            this.energy.Location = new System.Drawing.Point(19, 90);
            this.energy.Name = "energy";
            this.energy.Size = new System.Drawing.Size(25, 25);
            this.energy.TabIndex = 15;
            this.energy.TabStop = false;
            // 
            // drinks
            // 
            this.drinks.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("drinks.BackgroundImage")));
            this.drinks.Location = new System.Drawing.Point(19, 50);
            this.drinks.Name = "drinks";
            this.drinks.Size = new System.Drawing.Size(25, 25);
            this.drinks.TabIndex = 14;
            this.drinks.TabStop = false;
            // 
            // description
            // 
            this.description.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.description.Location = new System.Drawing.Point(71, 53);
            this.description.Name = "description";
            this.description.Size = new System.Drawing.Size(233, 216);
            this.description.TabIndex = 13;
            this.description.Text = "info";
            // 
            // infCheck
            // 
            this.infCheck.AutoSize = true;
            this.infCheck.Font = new System.Drawing.Font("Arial Black", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.infCheck.Location = new System.Drawing.Point(14, 10);
            this.infCheck.Name = "infCheck";
            this.infCheck.Size = new System.Drawing.Size(58, 30);
            this.infCheck.TabIndex = 0;
            this.infCheck.Text = "text";
            // 
            // intMap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 532);
            this.Controls.Add(this.infoCheck);
            this.Controls.Add(this.start_m);
            this.Controls.Add(this.ch8);
            this.Controls.Add(this.ch7);
            this.Controls.Add(this.ch6);
            this.Controls.Add(this.ch5);
            this.Controls.Add(this.ch4);
            this.Controls.Add(this.ch3);
            this.Controls.Add(this.ch2);
            this.Controls.Add(this.ch1);
            this.Controls.Add(this.map);
            this.Controls.Add(this.panel1);
            this.Name = "intMap";
            this.Load += new System.EventHandler(this.intMap_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.map)).EndInit();
            this.infoCheck.ResumeLayout(false);
            this.infoCheck.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.info)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toulet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.energy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.drinks)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.PictureBox map;
		private System.Windows.Forms.Button ch1;
		private System.Windows.Forms.Button back;
		private System.Windows.Forms.Button ch2;
		private System.Windows.Forms.Button ch3;
		private System.Windows.Forms.Button ch4;
		private System.Windows.Forms.Button ch5;
		private System.Windows.Forms.Button ch6;
		private System.Windows.Forms.Button ch7;
		private System.Windows.Forms.Button ch8;
		private System.Windows.Forms.Button start_m;
		private System.Windows.Forms.Panel infoCheck;
		private System.Windows.Forms.Label infCheck;
		private System.Windows.Forms.Label description;
		private System.Windows.Forms.PictureBox medic;
		private System.Windows.Forms.PictureBox info;
		private System.Windows.Forms.PictureBox toulet;
		private System.Windows.Forms.PictureBox energy;
		private System.Windows.Forms.PictureBox drinks;
		private System.Windows.Forms.PictureBox close;
	}
}